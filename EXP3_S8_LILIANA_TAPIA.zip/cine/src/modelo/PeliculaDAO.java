/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import bd.Conexion;
import java.sql.*;

public class PeliculaDAO {

    public void insertarPelicula(String id, String titulo, String director, String año, String duracion, String genero) throws SQLException {
        Conexion conexion1 = new Conexion();
        Connection cnx = conexion1.obtenerConexion();
        
        try {
            String sql = "{call moviesDB.insertar_pelicula(?,?,?,?,?,?)}";
            CallableStatement stmt = cnx.prepareCall(sql);
            stmt.setString(1, id);
            stmt.setString(2, titulo);
            stmt.setString(3, director);
            stmt.setString(4, año);
            stmt.setString(5, duracion);
            stmt.setString(6, genero);
            stmt.execute();
        } catch (SQLException e) {
            throw new SQLException("Error al insertar película: " + e.getMessage());
        } finally {
            cnx.close();
        }
    }
   
    // Método para modificar una película por ID
    public boolean modificarPelicula(int id, String titulo, String director, int anio, int duracion, String genero) {
        PreparedStatement pstmt = null;
        Conexion conexion1 = new Conexion();
        Connection cnx = conexion1.obtenerConexion();

        try {
            String query = "UPDATE moviesDB.MOVIE SET titulo = ?, director = ?, anio = ?, duracion = ?, genero = ? WHERE id_movie = ?";
            pstmt = cnx.prepareStatement(query);
            pstmt.setString(1, titulo);
            pstmt.setString(2, director);
            pstmt.setInt(3, anio);
            pstmt.setInt(4, duracion);
            pstmt.setString(5, genero);
            pstmt.setInt(6, id);

            // Ejecutar la consulta de modificación
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0; // Devuelve true si se modificó al menos una película
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Devuelve false en caso de error
        } finally {
            // Cerrar los recursos
            try {
                if (pstmt != null) pstmt.close();
                if (cnx != null) cnx.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}


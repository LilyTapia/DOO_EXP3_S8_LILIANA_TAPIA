/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

/**
 *
 * @author lilianatapia
 */

import modelo.PeliculaDAO;
import bd.Conexion;
import java.util.ArrayList;
import java.sql.*;

public class ControladorPelicula {

    private PeliculaDAO peliculaDAO;

    public ControladorPelicula() {
        this.peliculaDAO = new PeliculaDAO();
    }

    public boolean agregarPelicula(String id, String titulo, String director, String año, String duracion, String genero) {
        try {
            peliculaDAO.insertarPelicula(id, titulo, director, año, duracion, genero);
            return true;  // Retorna verdadero si la inserción fue exitosa
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return false;  // Retorna falso si hubo un error
        }
    }
    
    public boolean eliminarPeliculaPorTitulo(String titulo) {
        PreparedStatement pstmt = null;
        Conexion conexion1 = new Conexion();
        Connection cnx = conexion1.obtenerConexion();

        try {

            String query = "DELETE FROM moviesDB.MOVIE WHERE titulo = ?";

            // Crear un PreparedStatement para evitar inyecciones SQL
            pstmt = cnx.prepareStatement(query);
            pstmt.setString(1, titulo);

            // Ejecutar la consulta de eliminación
            int filasAfectadas = pstmt.executeUpdate();

            // Si se eliminó al menos una fila, el retorno será verdadero
            return filasAfectadas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Si ocurre un error, retornar falso
        } finally {
            // Cerrar los recursos
            try {
                if (pstmt != null) pstmt.close();
                if (cnx != null) cnx.close();
            } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        public Object[][] listarPeliculas() throws SQLException {
        ArrayList<Object[]> peliculas = new ArrayList<>();

        Connection cnx = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {

            Conexion conexion = new Conexion();
            cnx = conexion.obtenerConexion();

            // Consulta SQL
            String query = "SELECT id_movie, titulo, director, anio, duracion, genero FROM moviesDB.MOVIE ORDER BY titulo";
            stmt = cnx.createStatement();
            rs = stmt.executeQuery(query);

            // Rellenar la lista con los datos obtenidos
            while (rs.next()) {
                Object[] fila = new Object[6];
                fila[0] = rs.getInt("id_movie");
                fila[1] = rs.getString("titulo");
                fila[2] = rs.getString("director");
                fila[3] = rs.getInt("anio");
                fila[4] = rs.getInt("duracion");
                fila[5] = rs.getString("genero");
                peliculas.add(fila);
            }

        } finally {
            // Cerrar los recursos
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (cnx != null) cnx.close();
        }

        // Convertir la lista a un array de objetos
        return peliculas.toArray(new Object[0][]);
    }
}